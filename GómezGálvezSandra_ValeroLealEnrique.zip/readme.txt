Our notebook that describes the experiment is in the folder notebooks

In the folder data, the data must be included

In the folder queries, we store the information related to the queries (relevance judgements, etc)